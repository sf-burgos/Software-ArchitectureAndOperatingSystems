#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

char formas[60] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};

struct numero {
	char number[500];
};

int ascii(char b){
	int j,a;
	if ((int)b<65){
		a = (int)b -(int)'0';
	}
	else{
		a = (int)b -(int)'A' + 10;
	}
	return a;
}

int esCero(struct numero num){
	int res=1,i;
	for (i=0;i<strlen(num.number);i++){
		if(num.number[i] != '0'){
			res = 0;
		}
	}
	return res;	
}

int isSmaller(struct numero x,struct numero y){
	int n1=strlen(x.number),n2=strlen(y.number);
	if(n1<n2){
		return 1;
	}else if(n2<n1){
		return 0;
	}
	int i;
	for (i=0;i<n1;i++){
		if((x.number[i]-'0')<(y.number[i]-'0')){
			return 1;
		}else if((x.number[i]-'0')>(y.number[i]-'0')){
			return 0;
		}
	}
	return 0;
}


bool reviseNum(struct numero num,int baseIn){
	int j;
	int nume = strlen(num.number);
	int act;
	bool ver = true;
	for	(j=nume-1; 0<=j; j-=1){
		act = ascii(num.number[j]);
		if(act >= baseIn){
			ver = false;
		}
	}
	return ver;
}

struct numero rev(struct numero cad){
	struct numero temp;
	int pos,i;
	memset(temp.number,'\0',sizeof temp.number);
	pos = 0;
	for (i= strlen(cad.number)-1 ; i>=0 ;i--){
		temp.number[pos] = cad.number[i];
		pos ++;
	}
	return temp;
}

struct numero quitarCeros(struct numero x){
	struct numero res;
	memset(res.number,'\0',sizeof res.number);
	int bandera = 0,i,pos;
	pos = 0;
	for(i = 0; i<strlen(x.number)-1;i++){
		if (x.number[i] != '0' && bandera == 0){
			bandera = 1;
		}
		if (bandera == 1){
			res.number[pos] = x.number[i];
			pos ++; 
		}
	}
	res.number[strlen(res.number)] = x.number[strlen(x.number)-1];
	return res;
}

struct numero suma(struct numero x,struct numero y){
	struct numero res,a,b;
	memset(res.number,'\0',sizeof res.number);
	if (strlen(x.number)>strlen(y.number)){
		a=x;
		b=y;
	}else{
		a=y;
		b=x;
	}
	a = rev(a);
	b = rev(b);
	int lna=strlen(a.number), lnb=strlen(b.number), carry=0,n,i;
	for (i=0;i<lnb;i++){
		int sum = (a.number[i]-'0') + (b.number[i]-'0') + carry;
		carry=sum/10;
		n= sum%10;
		res.number[i]=(n + '0');
	}
	
	for(i=lnb;i<lna;i++){
		int sum = (a.number[i]-'0')+carry;
		carry=sum/10;
		n= sum%10;
		res.number[i]=(n + '0');
	}
	if(carry>0){
		res.number[strlen(res.number)]=(carry + '0');
	}
	res = rev(res);
	return res;
}


struct numero multiplicacion(struct numero x,struct numero y){
	int i, j,num1,num2,res,carry,guar,pos;
	struct numero resu,temp;
	memset(resu.number,'\0',sizeof resu.number);
	memset(temp.number,'\0',sizeof temp.number);
	x = rev(x);
	y = rev(y);
	for (i=0;i<strlen(y.number);i++){
		carry = 0;
		for (j=0;j<strlen(x.number);j++){
			num1 = ascii(x.number[j]);
			num2 = ascii(y.number[i]);
			res = (num1*num2)+carry;
			if(resu.number[i+j] != '\0'){
				res = res + (ascii(resu.number[i+j]));
			}
			carry = res/10;
			guar = res%10;
			resu.number[i+j] = guar+'0';
			pos = i+j;
		}
		if (carry != 0){
			resu.number[strlen(resu.number)] = carry + '0';
		}
	}
	resu = rev(resu);
	if(y.number[strlen(y.number)-2]!='\0' && y.number[strlen(y.number)-1]!= '\0'){
		if(ascii(y.number[strlen(y.number)-2])>=0 && ascii(y.number[strlen(y.number)-1])> 0 && ascii(x.number[strlen(x.number)-1])==0 && resu.number[0] == '0'){
			for(i=1;i<strlen(resu.number);i++){
				temp.number[i-1]=resu.number[i];
			}
		resu = temp;
		}	
		
	}
	return resu;
}

struct numero resta(struct numero x,struct numero y){
	struct numero res,a,b;
	int pos=0;
	memset(res.number,'\0',sizeof res.number);
	if(isSmaller(x,y)==1){
		a=y;
		b=x;
	}else{
		a=x;
		b=y;
	}
	int lna=strlen(a.number),lnb=strlen(b.number);
	a=rev(a);
	b = rev(b);
	int carry=0,i;
	
	for (i=0;i<lnb;i++){
		int sub = ((a.number[i]-'0')-(b.number[i]-'0')-carry);
		if (sub<0){
			sub=sub+10;
			carry=1;
		}else{
			carry=0;
		}
		res.number[pos]= sub + '0';
		pos++;
	}
	
	for(i = lnb; i<lna;i++){
		int sub = (a.number[i]-'0')-carry;
		if (sub<0){
			sub=sub+10;
			carry=1;
		}else{
			carry=0;
		}
		res.number[pos]= sub + '0';
		pos++;
	}
	res = rev(res);
	res = quitarCeros(res);
	return res;
}

struct numero division (struct numero x,struct numero y){
	struct numero res,temp;
	
	char fin;
	int i,cont,salto = 1,con = 0;
	cont = 0;
	memset(res.number,'\0',sizeof res.number);
	memset(temp.number,'\0',sizeof temp.number);
	//x.number[strlen(x.number)] = '0';
	while (x.number[0]-'0' != 0 && con != 200){
		if(isSmaller(x,y)== 1){
			if(salto == 1){
				res.number[strlen(res.number)] = formas[cont];
				x.number[strlen(x.number)] = '0';
				salto = 0;
			}
			else{
				res.number[strlen(res.number)] = formas[cont];
				x.number[strlen(x.number)] = '0';
			}
			cont = 0;
		}
		else{
			x = resta(x,y);
			cont++;
			salto = 1;
			con ++;
		}
		
	}
	res.number[strlen(res.number)] = cont + '0';
	if(x.number[0]-'0' != 0 && strlen(res.number) != 17){
		fin = res.number[strlen(res.number)-1];
		for(i = strlen(res.number)-1 ; i<=14 ;i++){
			res.number[i] = fin;
		}
	}
	return res;	
}

struct numero potencia(int y,int base){
	struct numero resu,a;
	int i;
    memset(resu.number,'\0',sizeof resu.number);
    memset(a.number,'\0',sizeof a.number);
    if(base/10 != 0){
		resu.number[0]= (base/10) + '0';
		resu.number[1]= (base%10) + '0';
		a.number[0]= (base/10) + '0';
		a.number[1]= (base%10) + '0';
	}
	else{
		resu.number[0]= (base%10) + '0';
		a.number[0]= (base%10) + '0';
	}
    if(y == 0){
    	resu.number[0] = '1';
    	resu.number[1] = '\0';
	}
	else{
		for (i=0;i<y-1;i++){
        	resu=multiplicacion(a,resu);
    	}
	}
    return resu;
}

struct numero aBase10(struct numero num, int baseIn){
	struct numero res,temp,dec;
	int i,pot;
	memset(dec.number,'\0',sizeof dec.number);
	memset(res.number,'\0',sizeof res.number);
	memset(temp.number,'\0',sizeof temp.number);
	dec.number[0] = '0';
	pot = strlen(num.number)-3;
	for (i= 2; i<strlen(num.number) ;i++){
		if (num.number[i] != '0'){
			if((ascii(num.number[i]))/10 != 0){
				temp.number[0]= (ascii(num.number[i])/10) + '0';
				temp.number[1]= (ascii(num.number[i])%10) + '0';
			}
			else{
				temp.number[0]= (ascii(num.number[i])%10) + '0';
				temp.number[1]= '\0';
			}
			
			dec = suma(dec,multiplicacion(potencia(pot,baseIn),temp));
		}
		pot--;
	}
	dec = division(dec,potencia(strlen(num.number)-2,baseIn));
	return dec;
}

struct numero cambioBase(struct numero num, struct numero basefin){
	struct numero res,dec,mult,temp;
	char prim;
	int longDec,prime;
	longDec = strlen(num.number)-1;
	memset(res.number,'\0',sizeof res.number);
	memset(temp.number,'\0',sizeof temp.number);
	int i,con=0;
	while(con < 15 && esCero(num) == 0){
		memset(dec.number,'\0',sizeof dec.number);
		con ++;
		mult = multiplicacion(num,basefin);
		if(strlen(mult.number)-2 == longDec){
			num = mult;
			prime = (num.number[0]-'0')*10 +(num.number[1]-'0');
			res.number[strlen(res.number)]=formas[prime];
			temp.number[0]= '0';
			for (i= 2; i< strlen(num.number) ;i++){
				temp.number [i-1] = num.number[i];
			}
			num = temp;
		}
		else{
			num = mult;
			res.number[strlen(res.number)]=num.number[0];
			num.number[0]='0';
		}
		
	}
	printf("0");
	printf(".");
	return res;
}

int main(){
	struct numero res,dec,num,baseFin;
	memset(res.number,'\0',sizeof res.number);
	memset(dec.number,'\0',sizeof dec.number);
	memset(num.number,'\0',sizeof num.number);
	memset(baseFin.number,'\0',sizeof baseFin.number);
	int i, baseIn, basefin,cant;
	scanf("%d", &cant);
	for	(i=0; i<cant; i++){
		scanf("%d",&baseIn);
		scanf("%s",&num.number);
		scanf("%d",&basefin);
		if(baseIn <=1 || baseIn > 36  ){
			printf("%s", "Error base origen\n");
		}
		else if(reviseNum(num,baseIn) == false){
			printf("%s", "Error numero\n");
		}
		else if(basefin <2 || basefin > 36) {
			printf("%s", "Error base destino\n");
		}
		else if(baseIn == basefin){
			printf("%s\n", num.number);
		}
		else{
			if(basefin/10 != 0){
				baseFin.number[0]= (basefin/10) + '0';
				baseFin.number[1]= (basefin%10) + '0';
			}
			else{
				baseFin.number[0]= (basefin%10) + '0';
				baseFin.number[1]= '\0';
			}
			
			dec = aBase10(num,baseIn);
			res = cambioBase(dec,baseFin);
			printf("%s \n",res.number);
		}
	}
	return 0;
}
