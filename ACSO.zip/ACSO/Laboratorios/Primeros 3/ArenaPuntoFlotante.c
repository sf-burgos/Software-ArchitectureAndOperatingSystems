#include<stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

struct numero {
	char number[500];
};

struct numero rev(struct numero cad){
	struct numero temp;
	int pos,i;
	memset(temp.number,'\0',sizeof temp.number);
	pos = 0;
	for (i= strlen(cad.number)-1 ; i>=0 ;i--){
		temp.number[pos] = cad.number[i];
		pos ++;
	}
	return temp;
}

int isSmaller(struct numero x,struct numero y){
	int n1=strlen(x.number),n2=strlen(y.number);
	if(n1<n2){
		return 1;
	}else if(n2<n1){
		return 0;
	}
	int i;
	for (i=0;i<n1;i++){
		if((x.number[i]-'0')<(y.number[i]-'0')){
			return 1;
		}else if((x.number[i]-'0')>(y.number[i]-'0')){
			return 0;
		}
	}
	return 0;
}


struct numero complemento1(struct numero num,int prec){
	struct numero comp1;
	int i,dif;
	memset(comp1.number,'\0',sizeof comp1.number);
	for (i= 0 ; i<prec ;i++){
		if(num.number[i]=='0'){
			comp1.number[i]='1';
		}
		else{
			comp1.number[i]='0';
		}
	}
	return comp1;
}

struct numero complemento2(struct numero num,int prec){
	struct numero temp;
	int i,dif,bandera = 0;
	memset(temp.number,'\0',sizeof temp.number);
	for (i=prec-1  ; i>=0 ;i--){
		if(bandera == 0 && num.number[i] == '0'){
			temp.number[i] = '0'; 
		}
		else if(bandera == 0 && num.number[i] == '1'){
			bandera = 1;
			temp.number[i] = '1';
		}
		else if(bandera == 1 && num.number[i] == '1'){
			temp.number[i] = '0';
		}
		else{
			temp.number[i] = '1';
		}
	}
	return temp;
}

struct numero quitarCeros(struct numero x){
	struct numero res;
	memset(res.number,'\0',sizeof res.number);
	int bandera = 0,i,pos;
	pos = 0;
	for(i = 0; i<strlen(x.number)-1;i++){
		if (x.number[i] != '0' && bandera == 0){
			bandera = 1;
		}
		if (bandera == 1){
			res.number[pos] = x.number[i];
			pos ++; 
		}
	}
	res.number[strlen(res.number)] = x.number[strlen(x.number)-1];
	return res;
}

struct numero resta(struct numero x,struct numero y){
	struct numero res,a,b;
	int pos=0;
	memset(res.number,'\0',sizeof res.number);
	if(isSmaller(x,y)==1){
		a=y;
		b=x;
	}else{
		a=x;
		b=y;
	}
	int lna=strlen(a.number),lnb=strlen(b.number);
	a=rev(a);
	b = rev(b);
	int carry=0,i;
	
	for (i=0;i<lnb;i++){
		int sub = ((a.number[i]-'0')-(b.number[i]-'0')-carry);
		if (sub<0){
			sub=sub+10;
			carry=1;
		}else{
			carry=0;
		}
		res.number[pos]= sub + '0';
		pos++;
	}
	
	for(i = lnb; i<lna;i++){
		int sub = (a.number[i]-'0')-carry;
		if (sub<0){
			sub=sub+10;
			carry=1;
		}else{
			carry=0;
		}
		res.number[pos]= sub + '0';
		pos++;
	}
	res = rev(res);
	res = quitarCeros(res);
	return res;
}

struct numero suma(struct numero x,struct numero y){
	struct numero res,a,b;
	memset(res.number,'\0',sizeof res.number);
	if (strlen(x.number)>strlen(y.number)){
		a=x;
		b=y;
	}else{
		a=y;
		b=x;
	}
	a = rev(a);
	b = rev(b);
	int lna=strlen(a.number), lnb=strlen(b.number), carry=0,n,i;
	for (i=0;i<lnb;i++){
		int sum = (a.number[i]-'0') + (b.number[i]-'0') + carry;
		carry=sum/10;
		n= sum%10;
		res.number[i]=(n + '0');
	}
	
	for(i=lnb;i<lna;i++){
		int sum = (a.number[i]-'0')+carry;
		carry=sum/10;
		n= sum%10;
		res.number[i]=(n + '0');
	}
	if(carry>0){
		res.number[strlen(res.number)]=(carry + '0');
	}
	res = rev(res);
	return res;
}


struct numero multiplicacion(struct numero x,struct numero y){
	int i, j,num1,num2,res,carry,guar,pos;
	struct numero resu;
	memset(resu.number,'\0',sizeof resu.number);
	x = rev(x);
	y = rev(y);
	for (i=0;i<strlen(y.number);i++){
		carry = 0;
		for (j=0;j<strlen(x.number);j++){
			num1 = x.number[j] - '0';
			num2 = y.number[i] - '0';
			res = (num1*num2)+carry;
			if(resu.number[i+j] != '\0'){
				res = res + (resu.number[i+j]-'0');
			}
			carry = res/10;
			guar = res%10;
			resu.number[i+j] = guar+'0';
			pos = i+j;
		}
		if (carry != 0){
			resu.number[strlen(resu.number)] = carry + '0';
		}
	}
	resu = rev(resu);
	return resu;
}

struct numero potencia(int y){
	struct numero resu,a;
	int i;
    memset(resu.number,'\0',sizeof resu.number);
    memset(a.number,'\0',sizeof a.number);
    resu.number[0] = '2';
    a.number[0] = '2';
    if(y == 0){
    	resu.number[0] = '1';
	}
	else if (y == 1){
		resu.number[0] = '2';
	}
	else{
		for (i=0;i<y-1;i++){
        	resu=multiplicacion(a,resu);
    	}
	}
	
    return resu;
}

struct numero division (struct numero x,struct numero y){
	struct numero res;
	int cont,salto = 1;
	cont = 0;
	memset(res.number,'\0',sizeof res.number);
	x.number[strlen(x.number)] = '0';
	while (x.number[0]-'0' != 0){
		if(isSmaller(x,y)== 1){
			if(salto == 1){
				res.number[strlen(res.number)] = cont + '0';
				x.number[strlen(x.number)] = '0';
				salto = 0;
			}
			else{
				res.number[strlen(res.number)] = cont + '0';
				x.number[strlen(x.number)] = '0';
			}
			cont = 0;
		}
		else{
			x = resta(x,y);
			cont++;
			salto = 1;
		}
	}
	res.number[strlen(res.number)] = cont + '0';
	return res;	
}

struct numero aEntero(struct numero num){
	struct numero dec ;
	int i,pot;
	memset(dec.number,'\0',sizeof dec.number);
	pot = 0;
	for (i= strlen(num.number)-1 ; i>=0 ;i--){
		if (num.number[i] == '1'){
			dec = suma(dec,potencia(pot));	
		}
		pot++;
	}
	return dec;
}

struct numero aDecimal(struct numero num){
	struct numero dec,temp;
	int i,pot;
	memset(dec.number,'\0',sizeof dec.number);
	dec.number[0] = '0';
	pot = strlen(num.number)-1;
	for (i= 0; i<strlen(num.number) ;i++){
		if (num.number[i] == '1'){
			dec = suma(dec,potencia(pot));
		}
		pot--;
	}
	dec = division(dec,potencia(strlen(num.number)));
	return dec;
}

struct numero puntoFijo(struct numero num,int punFi){
	int i,posDec=0,posEnt=0,longi;
	struct numero dec,ent,resEnt,resDec,res;
	longi = strlen(num.number);
	memset(dec.number,'\0',sizeof dec.number);
	memset(ent.number,'\0',sizeof ent.number);
	memset(res.number,'\0',sizeof res.number);
	memset(resEnt.number,'\0',sizeof resEnt.number);
	memset(resDec.number,'\0',sizeof resDec.number);
	for (i= 0 ; i<longi ;i++){
		if(i< longi-punFi){
			ent.number[posEnt] = num.number[i];
			posEnt++;
		}
		else{
			dec.number[posDec] = num.number[i];
			posDec++;
		}
	}
	resEnt = aEntero(ent);
	if(strlen(resEnt.number)==0){
		resEnt.number[0] = '0';
	}
	if(strlen(resDec.number)==0){
		resDec.number[0] = '0';
	}
	res = resEnt;
	res.number[strlen(res.number)] = '.';
	resDec = aDecimal(dec);
	for (i=0;i<strlen(resDec.number);i++){
		res.number[strlen(res.number)] = resDec.number[i];
	}
	return res;
}


struct numero puntoFlotante(struct numero num , struct numero bias, int expo){
	int signo=0,i,posE = 0,posN = 0,movi =0,con,res,pun,punto;
	struct numero pExp,pNum,exp,nume,restar,uno,respu;
	memset(pExp.number,'\0',sizeof pExp.number);
	memset(pNum.number,'\0',sizeof pNum.number);
	memset(uno.number,'\0',sizeof uno.number);
	uno.number[0]='1';
	if(num.number[0]=='1'){
		signo = 1;
	}
	for(i = 1; i < strlen(num.number);i++){
		if(i < 1+expo){
			pExp.number[posE] = num.number[i];
			posE ++;
		}	
		else{
			pNum.number[posN] = num.number[i];
			posN ++;
		}
	}
	exp = aEntero(pExp);
	if(isSmaller(exp,bias) == 1){
		exp = resta(exp,bias);
		movi = 1;
	}
	else{
		exp = resta(exp,bias);
		movi = 0;
	}
	pNum = rev(pNum);
	pNum.number[strlen(pNum.number)] = '1';
	pNum = rev(pNum);
	if(movi == 0){
		expo = 0;
		for (i=0;i<strlen(exp.number);i++){
			expo = expo + ((exp.number[i]-'0')*(pow(10,strlen(exp.number)-(i+1))));
		}
		punto =expo;
		con = 0;
		for(i=0;i<punto;i++){
			if(pNum.number[con] == '\0'){
				pNum.number[con] = '0';
			}
			con ++;
		}
		punto =strlen(pNum.number) - punto;
	}
	else{
		expo = 0;
		for (i=0;i<strlen(exp.number);i++){
			expo = expo + ((exp.number[i]-'0')*(pow(10,i)));
		}
		punto = strlen(pNum.number)+expo;
		pNum = rev(pNum);
		con = 0;
		for(i=0;i<punto;i++){
			if(pNum.number[con] == '\0'){
				pNum.number[con] = '0';
			}
			con ++;
		}
		pNum = rev(pNum);
		
	}
	respu = puntoFijo(pNum,punto);
	return respu;
}


int main(){
	int prec,exp,punFi,cant,i,dif,pos,j,neg;
	struct numero x,comp1,comp2,num,num1,num2,num3,bias;
	memset(x.number,'\0',sizeof x.number);
	memset(num.number,'\0',sizeof num.number);
	scanf("%d %s %d %d", &prec,&bias.number,&exp,&punFi);
	scanf("%d", &cant);
	for	(i=0; i<cant; i++){
		scanf("%s",&x.number);
		if (strlen(x.number) < prec){
			dif = prec- strlen(x.number);
			for (j =0; j<dif;j++){
				num.number[j] = '0';
			}
			for (j =0; j<strlen(x.number);j++){
				num.number[j+dif] = x.number[j];
			}
		}
		else{
			num = x;
		}
		neg = 0;
		if (num.number[0] == '1'){
			neg = 1;
			comp1 = complemento1(num,prec);
			comp2 = complemento2(num,prec);
		}
		else{
			comp1=num;
			comp2=num;
		}
		
		if(neg == 1){
			printf("-");
		}
		num1 = puntoFijo(comp1,punFi);
		printf("%s ",num1.number);
		if(neg == 1){
			printf("-");
		}
		num2 = puntoFijo(comp2,punFi);
		printf("%s ",num2.number);
		num3 = puntoFlotante(num,bias,exp);
		if(neg == 1){
			printf("-");
		}
		printf("%s",num3.number);
		printf("\n");
	}
}

