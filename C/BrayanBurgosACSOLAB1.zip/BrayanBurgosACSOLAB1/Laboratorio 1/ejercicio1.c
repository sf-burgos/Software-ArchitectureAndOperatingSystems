#include <stdio.h>
int main(){
	int num1;
	scanf("%i", &num1);
	int num2;
	scanf("%i", &num2);
	int resultado;
	resultado=num1+num2;
	printf("%i\n",resultado);
}
