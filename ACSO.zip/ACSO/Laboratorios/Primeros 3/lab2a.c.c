#include<stdio.h>
#include <stdbool.h>
#include <string.h>

bool banderaGen = true;
int j,a;


int ascii(char b){
	if ((int)b<65){
		a = (int)b -(int)'0';
	}
	else{
		a = (int)b -(int)'A' + 10;
	}
	return a;
}

bool reviseNum(char numero[2000],int baseIn){
	int nume = strlen(numero);
	int act;
	bool ver = true;
	for	(j=nume-1; 0<=j; j-=1){
		act = ascii(numero[j]);
		if(act >= baseIn){
			ver = false;
		}
	}
	return ver;
}

long long aBase10(char numero[2000], int baseIn){
	long long nume = strlen(numero);
	long long act,pot = 0,acum = 0;
	for	(j=nume-1; 0<=j; j-=1){
		act =ascii(numero[j]);
		acum = acum + (long long)(act*(pow (baseIn, pot)));
		pot += 1; 			
	}
	return acum;
}

 cambiarBase(long long numeDeci,int basefin){
	bool bandera = true;
	long long actual,ent,res,i;
	int pos = 125;
	char numeFin[126] = {97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97,97};
	char formas[60] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
	actual = numeDeci;
	int numef = strlen(numeFin);
	while(bandera){
		ent = (long long)actual/(long long)basefin;
		res = (long long)actual%(long long)basefin;
		if (ent == 0){
			numeFin[pos]=formas[res];
			bandera = false;
		}
		else{
			numeFin[pos]=formas[res];
			actual = ent;
			pos = pos - 1;
			
		}
	}
	for	(i=0; i<numef ; i+=1){
		if(numeFin[i] != 97 ){
			printf("%c",numeFin[i]);
		}
	}
	printf("\n");
}

int main(){
	char numero[2000];
	int i, baseIn, basefin,cant;
	long long numeDeci;
	scanf("%d", &cant);
	for	(i=0; i<cant; i++){
		memset(numero,'\0',2000);
		scanf("%d",&baseIn);
		scanf("%s",&numero);
		scanf("%d",&basefin);
		if(baseIn <=1 || baseIn > 36  ){
			printf("%s", "Error base origen\n");
		}
		else if(reviseNum(numero,baseIn) == false){
			printf("%s", "Error numero\n");
		}
		else if(basefin <2 || basefin > 36) {
			printf("%s", "Error base destino\n");
		}
		else if(baseIn == basefin){
			printf("%s\n", numero);
		}
		else{
			numeDeci = aBase10(numero,baseIn);
			cambiarBase(numeDeci,basefin);
		}
	}
	return 0;
}

