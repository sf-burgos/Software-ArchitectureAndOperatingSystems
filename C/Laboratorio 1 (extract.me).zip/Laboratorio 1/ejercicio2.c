#include <stdio.h>
int main(){
	float num1;float num2;
	scanf("%f",&num1);
	scanf("%f",&num2);
	if (num1 > num2){
		printf("%f\n",num1);
	}else{
		printf("%f\n", num2);
	}
}
